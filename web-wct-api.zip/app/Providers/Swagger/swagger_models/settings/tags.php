<?php

/**
 * @OA\Tag(
 *     name="greeting",
 *     description="greet combines first and last name",
 * )
**/

?>