<?php
define('ROLE_ADMIN', 'Admin');
define('ROLE_USER', 'User');
